import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './components/Navbar';
import MovieList from './components/MovieList';

function App() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    axios.get('https://api.themoviedb.org/3/movie/popular?api_key=a8657d839c295681394518e80d3e3825') // Replace with actual API
      .then(response => {
        setMovies(response.data.results);
      })
      .catch(error => console.error('Error fetching movies:', error));
  }, []);

  return (
    <div>
      <Navbar />
      <div className="container mt-4">
        <MovieList movies={movies} />
      </div>
    </div>
  );
}

export default App;