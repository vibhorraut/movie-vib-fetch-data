import React from 'react';

function MovieCard({ movie }) {
  return (
    <div className="card h-100 shadow-sm">
      <img src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`} className="card-img-top" alt={movie.title} />
      <div className="card-body d-flex flex-column">
        <h5 className="card-title">{movie.title}</h5>
        <p className="card-text text-truncate">{movie.overview}</p>
        <a href={`/movie/${movie.id}`} className="btn btn-primary mt-auto">View Details</a>
      </div>
    </div>
  );
}

export default MovieCard;